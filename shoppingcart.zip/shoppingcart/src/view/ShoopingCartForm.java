package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import model.CatalogItem;
import model.SelectedItem;
import controller.CatalogueReader;


/*
 * User Interface for shopping cart
 */

public class ShoopingCartForm implements ActionListener {
	DefaultTableModel model;
	JTable table;
	private JTextField textField;
	CatalogueReader reader;
	JComboBox<String> comboBox;
	JLabel priceLabel;
	JLabel totalCost;
	JButton cancelItems;
	JButton restart;
	JLabel priceType;
	NumberFormat formatter = new DecimalFormat("#0.00");
	String[] columns = { "Item", "Unit Price", "Quatity", "Item Total" };

	public static void main(String[] args) {
		new ShoopingCartForm();
	}

	private void populateItemList(JComboBox<String> comboBox, List<String> items) {

		comboBox.addItem("");
		for (String item : items) {
			comboBox.addItem(item);

		}

	}

	public ShoopingCartForm() {
		reader = new CatalogueReader(); // read the catalogue from file.
		reader.loadCatalog();
		JFrame frame = new JFrame("Shopping Cart");
		JPanel mainPanel = new JPanel();
		JPanel inputPanel = new JPanel();

		JPanel cartPanel = new JPanel();
		String data[][] = null;

		model = new DefaultTableModel(data, columns);
		table = new JTable(model);
		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.yellow);

		JScrollPane pane = new JScrollPane(table);
		cartPanel.add(pane);
		JLabel selectItemLbl = new JLabel();
		selectItemLbl.setForeground(Color.BLUE);
		inputPanel.add(selectItemLbl);
		selectItemLbl.setText("Select Item");

		comboBox = new JComboBox<String>();
		comboBox.addActionListener(this);
		populateItemList(comboBox, reader.getAllItemNames());
		inputPanel.add(comboBox);

		JLabel lblPrice = new JLabel();
		lblPrice.setForeground(Color.BLUE);
		lblPrice.setText("Price");
		inputPanel.add(lblPrice);

		priceLabel = new JLabel();
		priceLabel.setText("\u00A3 ....");
		inputPanel.add(priceLabel);

		JLabel lblEnterQuantity = new JLabel();
		lblEnterQuantity.setForeground(Color.BLUE);
		lblEnterQuantity.setText("Enter Quantity");
		inputPanel.add(lblEnterQuantity);

		textField = new JTextField();
		textField.addActionListener(this);
		inputPanel.add(textField);
		textField.setColumns(10);
		
		
		priceType = new JLabel();
		priceType.setForeground(Color.BLUE);
		priceType.setText("Type");
		inputPanel.add(priceType);

		JPanel summaryPanel = new JPanel();

		cancelItems = new JButton();
		cancelItems.addActionListener(this);
		cancelItems.setText("Cancel Items");
		summaryPanel.add(cancelItems);

		restart = new JButton();
		restart.addActionListener(this);
		restart.setText("Next Customer");
		summaryPanel.add(restart);

		JLabel totalCostLbl = new JLabel();
		totalCostLbl.setText("Total Amount");

		totalCost = new JLabel();
		totalCost.setText("\u00A3 ....");

		summaryPanel.add(totalCostLbl);
		summaryPanel.add(totalCost);

		mainPanel.add(inputPanel);
		mainPanel.add(cartPanel);
		mainPanel.add(summaryPanel);

		frame.getContentPane().add(mainPanel);
		frame.setSize(700, 700);
		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void initFormValues() {
		totalCost.setText("\u00A3"+".....");
		priceLabel.setText("\u00A3 ....");
		comboBox.setSelectedItem("");

	}

	private void calculateTotal() {
		int rowCount = model.getRowCount();
		double total = 0D;
		for (int rowNum = 0; rowNum < rowCount; rowNum++) {
			String tot = (String) model.getValueAt(rowNum, 3);
			total = total + Double.valueOf(tot);
		}

		this.totalCost.setText("\u00A3" + Double.toString(total));

	}

	public int isUpdate(SelectedItem selectedItem) {

		int rowCount = model.getRowCount();

		for (int rowNum = 0; rowNum < rowCount; rowNum++) {
			String item = (String) model.getValueAt(rowNum, 0);
			if (item.equals(selectedItem.getCatItem().getItemName())) {
				return rowNum;
			}
		}

		return -1;

	}
	
	/**
	 * Add items to the cart.
	 * @param selectedItem
	 */

	void addRow(SelectedItem selectedItem) {
		int itemRow = isUpdate(selectedItem);
		if (itemRow > 0) {
			updateRow(selectedItem, itemRow);
			return;
		}
		String[] columnDetails = new String[columns.length];
		columnDetails[0] = selectedItem.getCatItem().getItemName();
		columnDetails[1] = Double
				.toString(selectedItem.getCatItem().getPrice());
		columnDetails[2] = Double.toString(selectedItem.getQuatity());
		columnDetails[3] = formatter.format((selectedItem.getTotalCost()));
		model.addRow(columnDetails);
		calculateTotal();

	}

	void clearAllRows() {
		int rowCount = table.getRowCount();

		for (int rowNum = rowCount-1; rowNum >= 0; rowNum--) {
			model.removeRow(rowNum);

		}
		model.fireTableDataChanged();
		calculateTotal();

	}

	void deleteRow() {
		int[] rows = table.getSelectedRows();
		if (rows.length > 0) {
			for (int rowNum = 0; rowNum < rows.length; rowNum++) {
				model.removeRow(rows[rowNum]);

			}
			model.fireTableDataChanged();
			calculateTotal();
		}

	}

	void updateRow(SelectedItem selectedItem, int rowNum) {
		String itemCost = (String) model.getValueAt(rowNum, 3);
		Double itemCostVal = Double.valueOf(itemCost);
		itemCostVal = itemCostVal + selectedItem.getTotalCost();
		model.setValueAt(Double.toString(itemCostVal), rowNum, 3);
		model.fireTableCellUpdated(rowNum, 3);
		calculateTotal();

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event != null && event.getSource().equals(cancelItems)) {
			deleteRow();

		}

		if (event != null && event.getSource().equals(comboBox)
				&& ((String) comboBox.getSelectedItem()).length() > 0
				&& priceLabel != null) {
			String itemName = (String) comboBox.getSelectedItem();
			CatalogItem item = reader.getItemForName(itemName);
			priceLabel.setText("\u00A3" + Double.toString(item.getPrice()));
			priceType.setText(item.getUnit());

		}

		if (event != null && event.getSource().equals(restart)) {
			reset();
			clearAllRows();
			initFormValues();

		}

		if (event != null && event.getSource().equals(textField)
				&& textField != null && textField.getText().length() > 0
				&& ((String) comboBox.getSelectedItem()).length() > 0) {
			String itemName = (String) comboBox.getSelectedItem();
			CatalogItem item = reader.getItemForName(itemName);
			String qtyStr = textField.getText();
			if(item.getUnit().contains("piece")){
				try {
				Integer.parseInt(qtyStr);
				} catch (NumberFormatException pe){
				JOptionPane.showMessageDialog(textField,"For this Item, quantity has to be full number");
				return;
				}
			}
			try {
				double qty = Double.valueOf(qtyStr);
				SelectedItem selectedItem = new SelectedItem();
				selectedItem.setCatItem(item);
				selectedItem.setQuatity(qty);
				selectedItem.setTotalCost(qty * item.getPrice());
				addRow(selectedItem);
				reset();
			} catch (NumberFormatException e) {
				e.printStackTrace(); // TODO Log4J logging in error category is
										// correct way to log.

			}
			priceLabel.setText("\u00A3" + Double.toString(item.getPrice()));

		}

	}

	private void reset() {
		textField.setText("");
		comboBox.setSelectedItem("");

		priceLabel.setText("\u00A3 ....");
		priceType.setText("");

	}

}