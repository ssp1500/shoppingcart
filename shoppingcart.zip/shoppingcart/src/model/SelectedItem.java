package model;


public class SelectedItem {
	private double quatity;
	private double totalCost;
	private CatalogItem catItem;
	
	public double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	public double getQuatity() {
		return quatity;
	}
	public void setQuatity(double quatity) {
		this.quatity = quatity;
	}
	public CatalogItem getCatItem() {
		return catItem;
	}
	public void setCatItem(CatalogItem catItem) {
		this.catItem = catItem;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((catItem == null) ? 0 : catItem.hashCode());
		long temp;
		temp = Double.doubleToLongBits(quatity);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(totalCost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectedItem other = (SelectedItem) obj;
		if (catItem == null) {
			if (other.catItem != null)
				return false;
		} else if (!catItem.equals(other.catItem))
			return false;
		if (Double.doubleToLongBits(quatity) != Double
				.doubleToLongBits(other.quatity))
			return false;
		if (Double.doubleToLongBits(totalCost) != Double
				.doubleToLongBits(other.totalCost))
			return false;
		return true;
	}
	

}
