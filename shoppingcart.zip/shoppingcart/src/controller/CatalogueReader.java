package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.CatalogItem;

public class CatalogueReader {

	final private String catalogResource = "catelog.csv";
	List<CatalogItem> items;

	
	
	
	/**
	 * Returns Catalog item for the given name.
	 * @param name
	 * @return
	 */
	
	
	public CatalogItem getItemForName(String name){
		
		if (items == null) {

			loadCatalog();

		}

		
		for (CatalogItem item : items) {

			if(item !=null && item.getItemName().equals(name)){
				
				return item;
			}

		}
		
		return null;
		
	}
	
	/**
	 * Returns List of product names.
	 * @return
	 */
	public List<String> getAllItemNames() {

		List<String> itemNames = new ArrayList<String>();

		if (items == null) {

			loadCatalog();

		}

		for (CatalogItem item : items) {

			itemNames.add(item.getItemName());

		}

		return itemNames;

	}

	/**
	 * Loads product Catalogue
	 * 
	 * @return
	 */

	public List<CatalogItem> loadCatalog() {
		items = new ArrayList<CatalogItem>();

		Scanner inputStream=null;
		// -read from file with Scanner class
		try {
		inputStream = new Scanner(getClass().getResourceAsStream(
				catalogResource));
		} catch (Exception e){
			inputStream = new Scanner(getClass().getResourceAsStream(
					"/"+catalogResource));
		}
		
		// ignore header
		inputStream.next();
		while (inputStream.hasNext()) {
			CatalogItem item = new CatalogItem();
			// read single line, put in string
			String data = inputStream.next();
			String[] itemDetails = data.split(",");
			item.setItemId(itemDetails[0]);
			item.setItemName(itemDetails[1]);
			item.setPrice((Double.parseDouble(itemDetails[2])));
			item.setUnit(itemDetails[3]);
			items.add(item);

		}
		// after loop, close scanner
		inputStream.close();
		return items;
	}

	public static void main(String args[]) {

		CatalogueReader reader = new CatalogueReader();
		reader.loadCatalog();

	}

}
