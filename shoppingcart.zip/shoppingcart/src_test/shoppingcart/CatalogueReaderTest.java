package shoppingcart;

import junit.framework.TestCase;
import controller.CatalogueReader;

public class CatalogueReaderTest extends TestCase {

	public void testCatalogueReader() {

		CatalogueReader reader = new CatalogueReader();
		assertTrue(reader.getAllItemNames() != null);
		assertTrue(reader.getAllItemNames().size() > 0);

	}

}
